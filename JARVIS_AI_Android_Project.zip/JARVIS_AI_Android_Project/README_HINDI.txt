JARVIS AI - Android prototype source

IMPORTANT:
- Yeh source project hai, ready-made APK nahi.
- Is prototype mein Hindi speech-to-text, Hindi text-to-speech aur kuch apps kholne ke basic commands hain.
- Ismein abhi online AI brain, always-on wake word, WhatsApp message sending, arbitrary phone control ya background listening nahi hai.
- Android security restrictions ke kaaran har setting/app ko unrestricted control nahi diya ja sakta.

APK banane ka aasaan tareeqa:
1. Is ZIP ko GitHub par naye repository mein upload karein.
2. Repository ka naam JarvisAI rakhein.
3. Actions tab kholein. Build JARVIS APK workflow run karein.
4. Workflow complete hone par JARVIS-AI-debug-apk artifact download karein.
5. ZIP artifact extract karke app-debug.apk Android phone mein install karein.
6. Install karte waqt Android ke prompt par is source se install allow karein.

Alternative:
Android Studio mein project open karke Build > Build Bundle(s) / APK(s) > Build APK(s) chunein.

App package: com.example.jarvisai
Minimum Android: Android 8.0 (API 26)
