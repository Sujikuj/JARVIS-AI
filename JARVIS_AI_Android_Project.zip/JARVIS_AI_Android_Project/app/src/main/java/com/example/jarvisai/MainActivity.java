package com.example.jarvisai;

import android.app.Activity;
import android.os.Bundle;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status, transcript;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private static final int REQ_AUDIO = 41;
    private final int cyan = Color.rgb(0, 220, 255);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(4, 10, 25));
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUI();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        if (SpeechRecognizer.isRecognitionAvailable(this))
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(24, 48, 24, 24);
        root.setBackgroundColor(Color.rgb(4, 10, 25));

        TextView title = new TextView(this);
        title.setText("J.A.R.V.I.S");
        title.setTextColor(cyan);
        title.setTextSize(32);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 80));

        status = new TextView(this);
        status.setText("SYSTEM ONLINE • READY");
        status.setTextColor(Color.WHITE);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 55));

        TextView orb = new TextView(this);
        orb.setText("◉");
        orb.setTextColor(cyan);
        orb.setTextSize(92);
        orb.setGravity(Gravity.CENTER);
        root.addView(orb, new LinearLayout.LayoutParams(-1, 180));

        transcript = new TextView(this);
        transcript.setText("Namaste! Main JARVIS hoon. Neeche button dabakar Hindi ya English mein baat karein.");
        transcript.setTextColor(Color.WHITE);
        transcript.setTextSize(17);
        transcript.setGravity(Gravity.CENTER);
        root.addView(transcript, new LinearLayout.LayoutParams(-1, 130));

        Button listen = new Button(this);
        listen.setText("🎙  TALK TO JARVIS");
        listen.setTextSize(16);
        listen.setOnClickListener(v -> listen());
        root.addView(listen, new LinearLayout.LayoutParams(-1, 60));

        Button yt = new Button(this); yt.setText("OPEN YOUTUBE");
        yt.setOnClickListener(v -> openApp("com.google.android.youtube", "YouTube"));
        root.addView(yt, new LinearLayout.LayoutParams(-1, 52));

        Button wa = new Button(this); wa.setText("OPEN WHATSAPP");
        wa.setOnClickListener(v -> openApp("com.whatsapp", "WhatsApp"));
        root.addView(wa, new LinearLayout.LayoutParams(-1, 52));

        Button chrome = new Button(this); chrome.setText("OPEN CHROME");
        chrome.setOnClickListener(v -> openApp("com.android.chrome", "Chrome"));
        root.addView(chrome, new LinearLayout.LayoutParams(-1, 52));

        TextView note = new TextView(this);
        note.setText("Prototype 1.0  |  Voice button required  |  AI chat + advanced controls are next modules");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(11);
        note.setGravity(Gravity.CENTER);
        root.addView(note, new LinearLayout.LayoutParams(-1, 70));
        setContentView(root);
    }

    private void listen() {
        if (recognizer == null) {
            say("Is phone par speech recognition available nahi hai.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS ko command dein");
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { status.setText("LISTENING..."); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { status.setText("PROCESSING..."); }
            public void onError(int e) { status.setText("READY"); transcript.setText("Awaaz samajh nahi aayi. Dobara try karein."); }
            public void onResults(Bundle r) {
                ArrayList<String> a = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (a != null && !a.isEmpty()) handleCommand(a.get(0));
                status.setText("SYSTEM ONLINE • READY");
            }
            public void onPartialResults(Bundle p) {}
            public void onEvent(int t, Bundle p) {}
        });
        recognizer.startListening(i);
    }

    private void handleCommand(String text) {
        transcript.setText("You: " + text);
        String q = text.toLowerCase(Locale.ROOT);
        if (q.contains("youtube")) { openApp("com.google.android.youtube", "YouTube"); return; }
        if (q.contains("whatsapp")) { openApp("com.whatsapp", "WhatsApp"); return; }
        if (q.contains("chrome") || q.contains("browser")) { openApp("com.android.chrome", "Chrome"); return; }
        if (q.contains("setting") || q.contains("सेटिंग")) {
            startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
            say("Phone settings khol raha hoon."); return;
        }
        say("Maine suna: " + text + ". Abhi mera basic prototype mode chalu hai. AI jawab dene ka module agle version mein jodega.");
    }

    private void openApp(String pkg, String name) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) { startActivity(launch); say(name + " khol raha hoon."); }
        else say(name + " app install nahi hai ya open nahi ho sakta.");
    }

    private void say(String s) {
        transcript.setText(s);
        if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
